// src/routes/PrivateRoute.tsx

import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../store/auth";

type Props = {
  children: React.ReactNode;
};

/** Si no hay token, redirige a /login. Si hay token, muestra el componente envuelto. */
export default function PrivateRoute({ children }: Props) {
  const { token } = useAuth();
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

