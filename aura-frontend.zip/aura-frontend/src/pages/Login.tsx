// src/pages/Login.tsx

import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../store/auth";
import { request } from "../lib/api";

export default function Login() {
  const navigate = useNavigate();
  const setToken = useAuth((state) => state.setToken);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  // Si ya hay token en localStorage (o Zustand), redirigimos directamente al dashboard
  useEffect(() => {
    const storedToken = localStorage.getItem("token");
    if (storedToken) {
      navigate("/", { replace: true });
    }
  }, [navigate]);

  // Cada vez que cambie email o password, borramos error anterior
  useEffect(() => {
    if (error) {
      setError(null);
    }
  }, [email, password]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    try {
      // Enviamos POST /auth/login
      const { token } = await request<{ token: string }>("/auth/login", {
        method: "POST",
        body: { email, password },
      });

      // Guardamos token en Zustand + localStorage
      setToken(token);

      // Redirigimos al dashboard
      navigate("/", { replace: true });
    } catch (err: any) {
      // err.message ya contiene el message real del backend (o "Bad Request" si vino sin JSON).
      setError(err.message || "Error al iniciar sesión");
    }
  }

  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-br from-primary to-accent">
      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-2xl shadow-xl p-8 w-80 space-y-4"
      >
        <h1 className="text-2xl font-bold text-center text-primary">
          Iniciar sesión
        </h1>
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <input
          name="email"
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="border rounded w-full p-2"
        />
        <input
          name="password"
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="border rounded w-full p-2"
        />
        <button
          type="submit"
          className="w-full py-2 bg-primary text-white rounded hover:bg-primary-dark"
        >
          Entrar
        </button>
        <p className="text-sm text-center">
          ¿No tienes cuenta?{" "}
          <Link to="/register" className="text-primary hover:underline">
            Regístrate
          </Link>
        </p>
      </form>
    </div>
  );
}

