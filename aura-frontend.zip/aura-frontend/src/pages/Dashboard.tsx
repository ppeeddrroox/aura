// src/pages/Dashboard.tsx

import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../store/auth";

export default function Dashboard() {
  const token = useAuth((state) => state.token);
  const setToken = useAuth((state) => state.setToken);
  const navigate = useNavigate();

  // Si no hay token, redirige al login
  useEffect(() => {
    if (!token) {
      navigate("/login", { replace: true });
    }
  }, [token, navigate]);

  function handleLogout() {
    setToken(null);
    navigate("/login", { replace: true });
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <nav className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Bienvenido a AURA</h1>
        <button
          onClick={handleLogout}
          className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
        >
          Cerrar sesión
        </button>
      </nav>
      <div className="space-y-4">
        <Link
          to="/add-device"
          className="block w-64 py-2 px-4 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          ➕ Añadir nuevo AURA
        </Link>
        <button
          onClick={() =>
            alert("Aquí más adelante podrás listar tus dispositivos AURA")
          }
          className="block w-64 py-2 px-4 bg-green-600 text-white rounded hover:bg-green-700"
        >
          📋 Mis dispositivos AURA
        </button>
      </div>
    </div>
  );
}

