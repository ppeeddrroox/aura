// src/pages/AddDevice.tsx

import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../store/auth";
import { request } from "../lib/api";

interface DeviceInput {
  name: string;
  description: string;
  type: string;
}

export default function AddDevice() {
  const token = useAuth((state) => state.token);
  const setToken = useAuth((state) => state.setToken);
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Si no hay token, redirige a login
  useEffect(() => {
    if (!token) {
      navigate("/login", { replace: true });
    }
  }, [token, navigate]);

  // Cada vez que cambie el formulario, limpiamos los mensajes
  useEffect(() => {
    if (error) setError(null);
    if (successMsg) setSuccessMsg(null);
  }, [name, description, type]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    const device: DeviceInput = { name, description, type };

    try {
      // Hacemos POST /devices con Authorization: Bearer <token>
      const created = await request<{
        id: number;
        name: string;
        description: string;
        type: string;
        createdAt: string;
      }>("/devices", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: device,
      });

      setSuccessMsg(`AURA "${created.name}" creada con ID ${created.id}`);
      setName("");
      setDescription("");
      setType("");

      // Opcional: redirigir al dashboard automáticamente
      // navigate("/", { replace: true });
    } catch (err: any) {
      // Si es 401, podríamos forzar logout
      if (err.message === "Unauthorized") {
        setToken(null);
        navigate("/login", { replace: true });
        return;
      }
      setError(err.message || "Error al crear el dispositivo");
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <nav className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Añadir nuevo AURA</h1>
        <Link
          to="/"
          className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
        >
          ← Volver al dashboard
        </Link>
      </nav>

      <div className="max-w-md mx-auto bg-white p-6 rounded shadow">
        {error && <p className="text-red-500 mb-2">{error}</p>}
        {successMsg && <p className="text-green-600 mb-2">{successMsg}</p>}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Nombre del AURA
            </label>
            <input
              type="text"
              className="mt-1 block w-full border rounded p-2"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej. Sensor Temperatura Sala"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Descripción
            </label>
            <textarea
              className="mt-1 block w-full border rounded p-2"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descripción breve del dispositivo"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Tipo
            </label>
            <input
              type="text"
              className="mt-1 block w-full border rounded p-2"
              value={type}
              onChange={(e) => setType(e.target.value)}
              placeholder="Ej. temperatura, luminosidad"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Crear AURA
          </button>
        </form>
      </div>
    </div>
  );
}

