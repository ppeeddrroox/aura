// src/App.tsx

import React from "react";
import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import AddDevice from "./pages/AddDevice";
import NotFound from "./pages/NotFound";
import ProtectedRoute from "./components/ProtectedRoute";

export default function App() {
  return (
    <Routes>
      {/* Rutas públicas */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Rutas protegidas → se envuelven en ProtectedRoute */}
      <Route element={<ProtectedRoute />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/add-device" element={<AddDevice />} />
      </Route>

      {/* Ruta catch-all (404) */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

