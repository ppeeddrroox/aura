import { Link } from "react-router-dom";
import { useAuth } from "../store/auth";

export default function Navbar() {
  const setToken = useAuth((s) => s.setToken);
  return (
    <header className="h-16 bg-primary text-white flex items-center px-6 shadow">
      <img src="/logo.svg" alt="AURA" className="h-8 mr-4" />
      <span className="font-semibold mr-auto">AURA</span>
      <nav className="space-x-4">
        <Link to="/" className="hover:underline">
          Dashboard
        </Link>
        <button onClick={() => setToken(null)} className="hover:underline">
          Salir
        </button>
      </nav>
    </header>
  );
}
