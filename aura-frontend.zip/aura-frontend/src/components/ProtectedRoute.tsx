// src/components/ProtectedRoute.tsx

import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../store/auth";

export default function ProtectedRoute() {
  const token = useAuth((state) => state.token);

  // Si no hay token, redirigimos a login
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // Si hay token, renderizamos el componente hijo vía <Outlet/>
  return <Outlet />;
}

