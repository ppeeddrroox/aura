export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT: "#6366f1", dark: "#4f46e5" }, // indigo-500/600
        accent: "#a855f7", // purple-500
      },
    },
  },
  plugins: [],
};

